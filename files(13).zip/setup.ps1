# setup.ps1
# AttributePainter — Windows development environment setup
#
# Run once after cloning to verify prerequisites and configure the project.
# Usage:
#   powershell -ExecutionPolicy Bypass -File scripts\setup.ps1
#   powershell -ExecutionPolicy Bypass -File scripts\setup.ps1 -NukeRoot "D:\Nuke17.0" -Build
#
param(
    [string]$NukeRoot = "C:\Program Files\Nuke17.0",
    [string]$UsdRoot  = "",
    [switch]$Build,           # configure + build after setup
    [switch]$Stubs,           # generate SDK stubs even if real SDK is present
    [switch]$Install          # install .dll to Nuke plugins after build (requires -Build)
)

$ErrorActionPreference = "Stop"

$RootDir   = Split-Path $PSScriptRoot
$BuildDir  = Join-Path $RootDir "build"
$StubsDir  = Join-Path $RootDir "stubs"

if (-not $UsdRoot) { $UsdRoot = Join-Path $NukeRoot "usd" }

# ── Colour helpers ─────────────────────────────────────────────────────────────
function Write-Ok  ([string]$msg) { Write-Host "  [OK]   $msg" -ForegroundColor Green  }
function Write-Warn([string]$msg) { Write-Host "  [WARN] $msg" -ForegroundColor Yellow }
function Write-Err ([string]$msg) { Write-Host "  [ERR]  $msg" -ForegroundColor Red    }
function Write-Info([string]$msg) { Write-Host "  [..]   $msg" -ForegroundColor Cyan   }

Write-Host ""
Write-Host "  AttributePainter — Windows Setup Check" -ForegroundColor White
Write-Host "  ========================================" -ForegroundColor DarkGray
Write-Host ""

$allOk = $true

# ── 1. CMake ───────────────────────────────────────────────────────────────────
Write-Info "Checking CMake..."
$cmake = Get-Command cmake -ErrorAction SilentlyContinue
if ($cmake) {
    $cmakeVer = (cmake --version 2>&1 | Select-String "cmake version").ToString().Trim()
    # Check minimum version 3.20
    $verNum = [version](($cmakeVer -split " ")[-1])
    if ($verNum -ge [version]"3.20") {
        Write-Ok "CMake $verNum"
    } else {
        Write-Warn "CMake $verNum found but 3.20+ required. Download: https://cmake.org/download/"
        $allOk = $false
    }
} else {
    Write-Err "CMake not found. Download: https://cmake.org/download/"
    $allOk = $false
}

# ── 2. Visual Studio ───────────────────────────────────────────────────────────
Write-Info "Checking Visual Studio..."
$vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
if (-not (Test-Path $vswhere)) {
    $vswhere = "${env:ProgramFiles}\Microsoft Visual Studio\Installer\vswhere.exe"
}
if (Test-Path $vswhere) {
    $vsPath = & $vswhere -latest -products * `
        -requires Microsoft.VisualStudio.Workload.NativeDesktop `
        -property installationPath 2>$null
    if ($vsPath) {
        $vsVersion = & $vswhere -latest -products * `
            -requires Microsoft.VisualStudio.Workload.NativeDesktop `
            -property catalog_productLineVersion 2>$null
        Write-Ok "Visual Studio $vsVersion at: $vsPath"

        # Check MSVC toolset
        $vcvars = Join-Path $vsPath "VC\Auxiliary\Build\vcvarsall.bat"
        if (Test-Path $vcvars) {
            Write-Ok "vcvarsall.bat found"
        } else {
            Write-Warn "vcvarsall.bat not found at: $vcvars"
            $allOk = $false
        }
    } else {
        Write-Err "No VS with 'Desktop development with C++' workload found."
        Write-Err "Install from: https://visualstudio.microsoft.com/downloads/"
        $allOk = $false
    }
} else {
    Write-Err "vswhere.exe not found — is Visual Studio installed?"
    $allOk = $false
}

# ── 3. Nuke SDK ────────────────────────────────────────────────────────────────
Write-Info "Checking Nuke SDK at: $NukeRoot"
$nukeOk = $false
if (Test-Path $NukeRoot) {
    $ddimageH = Join-Path $NukeRoot "include\DDImage\Op.h"
    $ddimageL = Join-Path $NukeRoot "DDImage.lib"
    if ((Test-Path $ddimageH) -and (Test-Path $ddimageL)) {
        Write-Ok "Nuke NDK found (headers + DDImage.lib)"
        $nukeOk = $true
    } elseif (Test-Path $ddimageH) {
        Write-Warn "Nuke headers found but DDImage.lib missing at: $ddimageL"
        Write-Warn "Check your Nuke install — the .lib should be in the root folder."
    } else {
        Write-Warn "Nuke install found but NDK headers missing at: $NukeRoot\include"
        Write-Warn "You may need the Nuke NDK (separate download from The Foundry)."
    }
} else {
    Write-Warn "Nuke not found at: $NukeRoot"
    Write-Warn "Pass -NukeRoot to specify location, e.g.:"
    Write-Warn "  scripts\setup.ps1 -NukeRoot 'D:\Nuke17.0'"
}

if (-not $nukeOk) {
    Write-Warn "Using stub SDK for compile checking."
    Write-Warn "The plugin will NOT link against real Nuke — for development/CI only."
    $Stubs = $true
}

# ── 4. USD ────────────────────────────────────────────────────────────────────
Write-Info "Checking USD at: $UsdRoot"
$usdOk = $false
if (Test-Path $UsdRoot) {
    $usdH = Join-Path $UsdRoot "include\pxr\pxr.h"
    $usdL = Join-Path $UsdRoot "lib\usd_usd.lib"
    if ((Test-Path $usdH) -and (Test-Path $usdL)) {
        Write-Ok "OpenUSD found (headers + usd_usd.lib)"
        $usdOk = $true
    } else {
        Write-Warn "USD directory found but expected files missing."
        Write-Warn "  Headers: $usdH  → $(if (Test-Path $usdH) {'OK'} else {'MISSING'})"
        Write-Warn "  Lib:     $usdL  → $(if (Test-Path $usdL) {'OK'} else {'MISSING'})"
    }
} else {
    Write-Warn "USD not found at: $UsdRoot"
}
if (-not $usdOk) {
    $Stubs = $true
}

# ── 5. Generate stubs if needed ───────────────────────────────────────────────
if ($Stubs) {
    Write-Info "Generating SDK stubs..."
    $stubScript = Join-Path $PSScriptRoot "generate_stubs.ps1"
    if (Test-Path $stubScript) {
        & $stubScript -StubsRoot $StubsDir
        # Point at stubs
        if (-not $nukeOk) { $NukeRoot = Join-Path $StubsDir "nuke" }
        if (-not $usdOk)  { $UsdRoot  = Join-Path $StubsDir "usd"  }
        Write-Ok "Stubs generated at: $StubsDir"
    } else {
        Write-Err "generate_stubs.ps1 not found at: $stubScript"
        exit 1
    }
}

# ── Summary ───────────────────────────────────────────────────────────────────
Write-Host ""
if ($allOk -and $nukeOk -and $usdOk) {
    Write-Host "  All checks passed!" -ForegroundColor Green
} else {
    Write-Host "  Some checks have warnings — see above." -ForegroundColor Yellow
    Write-Host "  You can still build with stubs for compile checking." -ForegroundColor Yellow
}
Write-Host ""
Write-Host "  Effective paths:"
Write-Host "    NUKE_ROOT = $NukeRoot"
Write-Host "    USD_ROOT  = $UsdRoot"
Write-Host ""

# ── Optionally configure + build ──────────────────────────────────────────────
if ($Build) {
    Write-Info "Running build..."
    $buildScript = Join-Path $PSScriptRoot "build.bat"
    $installFlag = if ($Install) { "/install" } else { "" }

    $buildArgs = @(
        "/nuke", $NukeRoot,
        "/usd",  $UsdRoot,
        "/type", "Release"
    )
    if ($Install) { $buildArgs += "/install" }

    & cmd.exe /c `"$buildScript`" @buildArgs
    if ($LASTEXITCODE -ne 0) {
        Write-Err "Build failed with exit code $LASTEXITCODE"
        exit $LASTEXITCODE
    }
    Write-Ok "Build succeeded."
} else {
    Write-Host "  To build, run:" -ForegroundColor Cyan
    Write-Host "    scripts\build.bat /nuke `"$NukeRoot`" /usd `"$UsdRoot`""
    Write-Host ""
    Write-Host "  Or re-run setup with -Build:"
    Write-Host "    scripts\setup.ps1 -NukeRoot `"$NukeRoot`" -Build"
    Write-Host ""
}
