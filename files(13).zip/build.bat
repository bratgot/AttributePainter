@echo off
setlocal EnableDelayedExpansion

:: ─────────────────────────────────────────────────────────────────────────────
::  build.bat  —  AttributePainter  Windows / MSVC build script
::
::  Quick start:
::    scripts\build.bat
::
::  Full options:
::    scripts\build.bat [/nuke <dir>] [/usd <dir>] [/type Release|Debug]
::                      [/arch x64|x86] [/jobs N] [/install] [/clean] [/help]
:: ─────────────────────────────────────────────────────────────────────────────

:: ── Defaults ──────────────────────────────────────────────────────────────────
set "NUKE_ROOT=C:\Program Files\Nuke17.0"
set "USD_ROOT="
set "BUILD_TYPE=Release"
set "ARCH=x64"
set "JOBS=%NUMBER_OF_PROCESSORS%"
set "DO_INSTALL=0"
set "DO_CLEAN=0"

:: Derive root dir from script location (scripts\ is one level down from root)
set "SCRIPT_DIR=%~dp0"
for %%i in ("%SCRIPT_DIR%..") do set "ROOT_DIR=%%~fi"
set "BUILD_DIR=%ROOT_DIR%\build"

:: ── Argument parsing ──────────────────────────────────────────────────────────
:parse_args
if "%~1"==""         goto :after_args
if /i "%~1"=="/help" goto :show_help
if /i "%~1"=="/nuke" ( set "NUKE_ROOT=%~2"  & shift & shift & goto :parse_args )
if /i "%~1"=="/usd"  ( set "USD_ROOT=%~2"   & shift & shift & goto :parse_args )
if /i "%~1"=="/type" ( set "BUILD_TYPE=%~2" & shift & shift & goto :parse_args )
if /i "%~1"=="/arch" ( set "ARCH=%~2"       & shift & shift & goto :parse_args )
if /i "%~1"=="/jobs" ( set "JOBS=%~2"       & shift & shift & goto :parse_args )
if /i "%~1"=="/install" ( set "DO_INSTALL=1" & shift & goto :parse_args )
if /i "%~1"=="/clean"   ( set "DO_CLEAN=1"   & shift & goto :parse_args )
echo [ERROR] Unknown option: %~1
goto :show_help

:show_help
echo.
echo  Usage: scripts\build.bat [options]
echo.
echo  /nuke  ^<dir^>   Nuke install path  (default: C:\Program Files\Nuke17.0)
echo  /usd   ^<dir^>   USD root           (default: ^<nuke^>\usd)
echo  /type  ^<type^>  Release^|Debug^|RelWithDebInfo  (default: Release)
echo  /arch  ^<arch^>  x64^|x86           (default: x64)
echo  /jobs  ^<n^>     Parallel job count (default: %NUMBER_OF_PROCESSORS%)
echo  /install        Install .dll to Nuke plugins folder after build
echo  /clean          Delete build directory before configuring
echo  /help           Show this message
echo.
exit /b 0

:after_args
:: Derive USD root if not set explicitly
if "!USD_ROOT!"=="" set "USD_ROOT=!NUKE_ROOT!\usd"

:: ── Check for CMake ───────────────────────────────────────────────────────────
where cmake >nul 2>&1
if errorlevel 1 (
    echo [ERROR] cmake not found on PATH.
    echo         Download from https://cmake.org/download/ and add to PATH.
    exit /b 1
)
for /f "tokens=3" %%v in ('cmake --version 2^>^&1 ^| findstr /i "cmake version"') do (
    echo [info] CMake version: %%v
)

:: ── Locate Visual Studio with vswhere ────────────────────────────────────────
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "!VSWHERE!" (
    set "VSWHERE=%ProgramFiles%\Microsoft Visual Studio\Installer\vswhere.exe"
)
if not exist "!VSWHERE!" (
    echo [ERROR] vswhere.exe not found.
    echo         Install Visual Studio 2019 or 2022 with the
    echo         "Desktop development with C++" workload.
    exit /b 1
)

:: Find the latest VS that has the native desktop build tools
for /f "usebackq delims=" %%p in (
    `"!VSWHERE!" -latest -products * -requires Microsoft.VisualStudio.Workload.NativeDesktop -property installationPath 2^>nul`
) do set "VS_INSTALL=%%p"

if "!VS_INSTALL!"=="" (
    echo [ERROR] No Visual Studio installation found with NativeDesktop workload.
    echo         Install VS 2019 or 2022 with "Desktop development with C++".
    exit /b 1
)
echo [info] Visual Studio: !VS_INSTALL!

:: Initialise MSVC environment
set "VCVARS=!VS_INSTALL!\VC\Auxiliary\Build\vcvarsall.bat"
if not exist "!VCVARS!" (
    echo [ERROR] vcvarsall.bat not found at: !VCVARS!
    exit /b 1
)
call "!VCVARS!" !ARCH! >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Failed to initialise MSVC !ARCH! environment.
    exit /b 1
)
echo [info] MSVC environment initialised for !ARCH!

:: ── Warn if SDK paths are missing (might be a stub build) ────────────────────
if not exist "!NUKE_ROOT!" (
    echo [warn] NUKE_ROOT not found: !NUKE_ROOT!
    echo        Proceeding — will use stub libs if present.
)
if not exist "!USD_ROOT!" (
    echo [warn] USD_ROOT not found: !USD_ROOT!
)

:: ── Print summary ─────────────────────────────────────────────────────────────
echo.
echo  ─────────────────────────────────────────
echo   AttributePainter  Windows Build
echo  ─────────────────────────────────────────
echo   Nuke root  : !NUKE_ROOT!
echo   USD root   : !USD_ROOT!
echo   Build type : !BUILD_TYPE!
echo   Arch       : !ARCH!
echo   Jobs       : !JOBS!
echo   Build dir  : !BUILD_DIR!
echo  ─────────────────────────────────────────
echo.

:: ── Optional clean ────────────────────────────────────────────────────────────
if !DO_CLEAN!==1 (
    if exist "!BUILD_DIR!" (
        echo [info] Removing !BUILD_DIR!
        rmdir /s /q "!BUILD_DIR!"
    )
)

:: ── CMake configure ───────────────────────────────────────────────────────────
echo [info] Configuring...
cmake -B "!BUILD_DIR!" ^
    -G "Visual Studio 17 2022" ^
    -A !ARCH! ^
    -DCMAKE_BUILD_TYPE=!BUILD_TYPE! ^
    "-DNUKE_ROOT=!NUKE_ROOT!" ^
    "-DUSD_ROOT=!USD_ROOT!" ^
    "!ROOT_DIR!"

if errorlevel 1 (
    echo.
    echo [ERROR] CMake configure step failed.
    echo         Check that NUKE_ROOT and USD_ROOT are correct.
    exit /b 1
)

:: ── CMake build ───────────────────────────────────────────────────────────────
echo.
echo [info] Building (jobs=!JOBS!)...

:: Record start time
for /f "tokens=1-4 delims=:.," %%a in ("%time%") do (
    set /a "_start=(((%%a*60)+1%%b %% 100)*60+1%%c %% 100)*100+1%%d %% 100"
)

cmake --build "!BUILD_DIR!" --config !BUILD_TYPE! -- /maxcpucount:!JOBS!

if errorlevel 1 (
    echo.
    echo [ERROR] Build failed. Check output above for compiler errors.
    exit /b 1
)

:: Elapsed time
for /f "tokens=1-4 delims=:.," %%a in ("%time%") do (
    set /a "_end=(((%%a*60)+1%%b %% 100)*60+1%%c %% 100)*100+1%%d %% 100"
)
set /a "_elapsed=(_end - _start) / 100"
echo.
echo [OK] Build complete in !_elapsed!s

:: Find and report the DLL
for /r "!BUILD_DIR!" %%f in (AttributePainter.dll) do (
    echo [OK] Plugin: %%f
)

:: ── Optional install ──────────────────────────────────────────────────────────
if !DO_INSTALL!==1 (
    echo.
    echo [info] Installing to !NUKE_ROOT!\plugins ...
    cmake --install "!BUILD_DIR!" --config !BUILD_TYPE!
    if errorlevel 1 (
        echo [ERROR] Install failed.
        exit /b 1
    )
    echo [OK] Installed.
)

endlocal
exit /b 0
