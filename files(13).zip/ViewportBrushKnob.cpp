#include "ViewportBrushKnob.h"   // brings in windows.h + GL/glew.h in correct order
#include "AttributePainterOp.h"

#include <DDImage/ViewerContext.h>
#include <DDImage/Matrix4.h>
#include <DDImage/Vector3.h>
#include <DDImage/gl.h>

#include <cmath>
#include <algorithm>

// ── Portable PI ───────────────────────────────────────────────────────────────
// AP_PIf is a GNU extension; not available on MSVC even with _USE_MATH_DEFINES.
// Define our own to keep this file self-contained.
#ifndef AP_PIf
static constexpr float AP_PIf = 3.14159265358979323846f;
#endif

namespace AP {

// Number of segments for the brush circle overlay
static constexpr int BRUSH_CIRCLE_SEGS = 64;

ViewportBrushKnob::ViewportBrushKnob(DD::Image::Knob_Closure* kc,
                                     const char* name,
                                     AttributePainterOp* op)
    : DD::Image::Knob(kc, name), op_(op) {}

// ─────────────────────────────────────────────────────────────────────────────
//  Ray building from screen coordinates using Nuke's ViewerContext
// ─────────────────────────────────────────────────────────────────────────────

Ray ViewportBrushKnob::buildRay(DD::Image::ViewerContext* ctx,
                                 float sx, float sy) const {
    // Nuke provides camera matrices via ctx
    // Use unproject: take NDC coords → world space

    // Viewport dimensions
    int vpW = ctx->viewport().w();
    int vpH = ctx->viewport().h();

    // Normalised Device Coordinates [-1,1]
    float ndcX = (2.f * sx / float(vpW)) - 1.f;
    float ndcY = 1.f - (2.f * sy / float(vpH)); // flip Y

    // Fetch projection + modelview from ctx
    // Nuke uses DD::Image::Matrix4
    DD::Image::Matrix4 proj     = ctx->proj();
    DD::Image::Matrix4 modelview= ctx->modelview();
    DD::Image::Matrix4 invPV    = (proj * modelview).inverse();

    // Near point (z=-1 in NDC)
    DD::Image::Vector4 nearPt = invPV * DD::Image::Vector4(ndcX, ndcY, -1.f, 1.f);
    // Far point  (z=+1 in NDC)
    DD::Image::Vector4 farPt  = invPV * DD::Image::Vector4(ndcX, ndcY,  1.f, 1.f);

    DD::Image::Vector3 near3(nearPt.x/nearPt.w, nearPt.y/nearPt.w, nearPt.z/nearPt.w);
    DD::Image::Vector3 far3 ( farPt.x/ farPt.w,  farPt.y/ farPt.w,  farPt.z/ farPt.w);
    DD::Image::Vector3 dir  = far3 - near3;
    float len = dir.length();
    if (len > 1e-8f) dir /= len;

    return Ray{ {near3.x, near3.y, near3.z}, {dir.x, dir.y, dir.z} };
}

// ─────────────────────────────────────────────────────────────────────────────
//  Update hover hit point
// ─────────────────────────────────────────────────────────────────────────────

void ViewportBrushKnob::updateHit(DD::Image::ViewerContext* ctx) {
    hitValid_ = false;
    if (!sampler_ || !sampler_->isValid()) return;

    Ray ray = buildRay(ctx, mouseX_, mouseY_);
    lastHit_ = sampler_->intersect(ray);
    hitValid_ = lastHit_.hit;

    // Keep brush center updated so the op can draw it
    if (hitValid_) brushState_.center = lastHit_.position;
}

// ─────────────────────────────────────────────────────────────────────────────
//  Mouse events
// ─────────────────────────────────────────────────────────────────────────────

int ViewportBrushKnob::knob_mouse_move(DD::Image::ViewerContext* ctx) {
    if (!enabled_) return 0;
    mouseX_ = (float)ctx->mouse_x();
    mouseY_ = (float)ctx->mouse_y();
    updateHit(ctx);
    ctx->request_draw(); // trigger redraw for overlay
    return 1;
}

int ViewportBrushKnob::knob_mouse_down(DD::Image::ViewerContext* ctx) {
    if (!enabled_) return 0;
    if (ctx->button() != DD::Image::ViewerContext::kMouseLeft) return 0;

    mouseX_ = (float)ctx->mouse_x();
    mouseY_ = (float)ctx->mouse_y();
    updateHit(ctx);

    if (hitValid_) {
        painting_  = true;
        firstTick_ = true;
        if (onPaint_) onPaint_(lastHit_.position, lastHit_.normal, true);
        firstTick_ = false;
    }
    return 1;
}

int ViewportBrushKnob::knob_mouse_drag(DD::Image::ViewerContext* ctx) {
    if (!enabled_ || !painting_) return 0;

    mouseX_ = (float)ctx->mouse_x();
    mouseY_ = (float)ctx->mouse_y();
    updateHit(ctx);

    if (hitValid_ && onPaint_)
        onPaint_(lastHit_.position, lastHit_.normal, false);

    ctx->request_draw();
    return 1;
}

int ViewportBrushKnob::knob_mouse_up(DD::Image::ViewerContext* ctx) {
    if (!painting_) return 0;
    painting_ = false;
    if (onStrokeEnd_) onStrokeEnd_();
    ctx->request_draw();
    return 1;
}

int ViewportBrushKnob::knob_mouse_scroll(DD::Image::ViewerContext* ctx) {
    if (!enabled_) return 0;
    // Ctrl+scroll → resize brush
    if (ctx->state() & DD::Image::ViewerContext::kControlKey) {
        float delta = (ctx->scroll_delta() > 0) ? 1.1f : (1.f/1.1f);
        brushState_.radius = std::clamp(brushState_.radius * delta, 0.001f, 10.f);
        ctx->request_draw();
        return 1;
    }
    return 0;
}

// ─────────────────────────────────────────────────────────────────────────────
//  GL Overlay — draw brush circle
// ─────────────────────────────────────────────────────────────────────────────

void ViewportBrushKnob::draw_handle(DD::Image::ViewerContext* ctx) {
    if (!enabled_ || !hitValid_) return;

    // Only draw in 3D viewer passes
    if (ctx->draw_pass() != DD::Image::ViewerContext::kDraw3DPass) return;

    drawBrushCircle(ctx);
}

void ViewportBrushKnob::drawBrushCircle(DD::Image::ViewerContext* ctx) const {
    const Vec3f& c = brushState_.center;
    const Vec3f  n = lastHit_.normal;

    // Build an orthonormal basis on the surface (tangent, bitangent)
    Vec3f up = { 0.f, 1.f, 0.f };
    if (std::abs(n.dot(up)) > 0.99f) up = {1.f, 0.f, 0.f};

    // Gram-Schmidt
    float d = n.dot(up);
    Vec3f t = { up.x - n.x*d, up.y - n.y*d, up.z - n.z*d };
    float tlen = std::sqrt(t.lengthSq());
    if (tlen < 1e-8f) return;
    t = t * (1.f / tlen);

    // Bitangent = n × t
    Vec3f b = { n.y*t.z - n.z*t.y,
                n.z*t.x - n.x*t.z,
                n.x*t.y - n.y*t.x };

    float r = brushState_.radius;

    // ── Outer ring ──────────────────────────────────────────────────────────
    glPushAttrib(GL_LINE_BIT | GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
    glDepthFunc(GL_LEQUAL);
    glLineWidth(2.0f);
    glColor4f(1.f, 1.f, 1.f, 0.9f);

    glBegin(GL_LINE_LOOP);
    for (int i = 0; i < BRUSH_CIRCLE_SEGS; ++i) {
        float theta = (float)i / (float)BRUSH_CIRCLE_SEGS * 2.f * AP_PIf;
        float cosT = std::cos(theta);
        float sinT = std::sin(theta);
        Vec3f pt = {
            c.x + (t.x * cosT + b.x * sinT) * r,
            c.y + (t.y * cosT + b.y * sinT) * r,
            c.z + (t.z * cosT + b.z * sinT) * r,
        };
        // Offset slightly along normal to avoid z-fighting
        const float BIAS = 0.0005f;
        glVertex3f(pt.x + n.x*BIAS, pt.y + n.y*BIAS, pt.z + n.z*BIAS);
    }
    glEnd();

    // ── Inner ring (hardness) ────────────────────────────────────────────────
    float innerR = r * brushState_.hardness;
    glColor4f(1.f, 1.f, 0.f, 0.5f);
    glLineWidth(1.0f);
    glBegin(GL_LINE_LOOP);
    for (int i = 0; i < BRUSH_CIRCLE_SEGS; ++i) {
        float theta = (float)i / (float)BRUSH_CIRCLE_SEGS * 2.f * AP_PIf;
        float cosT = std::cos(theta);
        float sinT = std::sin(theta);
        Vec3f pt = {
            c.x + (t.x * cosT + b.x * sinT) * innerR,
            c.y + (t.y * cosT + b.y * sinT) * innerR,
            c.z + (t.z * cosT + b.z * sinT) * innerR,
        };
        const float BIAS = 0.0005f;
        glVertex3f(pt.x + n.x*BIAS, pt.y + n.y*BIAS, pt.z + n.z*BIAS);
    }
    glEnd();

    // ── Normal tick ──────────────────────────────────────────────────────────
    glColor4f(0.3f, 0.8f, 1.f, 0.8f);
    glBegin(GL_LINES);
        glVertex3f(c.x, c.y, c.z);
        glVertex3f(c.x + n.x*r*0.5f,
                   c.y + n.y*r*0.5f,
                   c.z + n.z*r*0.5f);
    glEnd();

    glPopAttrib();
}

} // namespace AP
